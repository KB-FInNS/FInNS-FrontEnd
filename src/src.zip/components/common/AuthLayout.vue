<template>
  <div class="auth-container">
    <router-view />
    <!-- 로그인 및 회원가입 페이지 렌더링 -->
  </div>
</template>

<script setup></script>

<style scoped></style>
