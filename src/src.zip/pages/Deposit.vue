<template>
  <div>
    <SearchFilter :categories="categories" @filter="applyFilter" />
    <ProductList :products="filteredProducts" />
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import SearchFilter from '@/components/common/SearchFilter.vue';
import ProductList from '@/components/common/ProductList.vue'; // 이름 변경

const categories = ['카테고리 1', '카테고리 2', '카테고리 3']; // 예시 카테고리
const products = ref([]); // 원래 상품 리스트
const filteredProducts = ref([]);

const applyFilter = (searchTerm, selectedCategory) => {
  filteredProducts.value = products.value.filter(product => {
    const matchesSearch = product.name.includes(searchTerm);
    const matchesCategory = selectedCategory ? product.category === selectedCategory : true;
    return matchesSearch && matchesCategory;
  });
};

onMounted(() => {
  // 상품 데이터를 가져오는 로직
  filteredProducts.value = products.value; // 모든 상품으로 초기화
});
</script>

<style scoped>
/* 여기에 관련 스타일 추가 */
</style>
