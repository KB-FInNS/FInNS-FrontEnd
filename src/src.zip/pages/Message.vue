<template>메시지 페이지!!</template>

<script setup></script>
